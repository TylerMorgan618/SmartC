## How to deploy

```
node --env-file=.env execute_deployment > process.txt
```

or with logs

```
node --env-file=.env execute_deployment --logs
```
