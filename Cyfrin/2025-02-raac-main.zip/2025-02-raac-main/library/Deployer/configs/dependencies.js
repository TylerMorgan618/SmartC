export default  {
    // crvUSDToken: {
    //     address: "0x721803756C3aAC531E0DFFfcA3Eb3Ad4370f7366",
    // },
    // RAACToken: {
    // 	address: "0xe076663B74BfD6597895A3B744D1eb0a9D2324b4",
    // },
    // veRAACToken: {
    // 	address: "0x25fFDF8F196F76dDc67BC92A18f6b5294B827283",
    // },
    // RAACReleaseOrchestrator: {
    // 	address: "0x66d2a4b9FBa8C6F60c16014EA6239007115503b6",
    // },
    // RAACHousePrices: {
    // 	address: "0x3Ae35C6CfbFeb8669bE90a08853098E2DCB6e964",
    // },
    // RAACNFT: {
    // 	address: "0x3f3fE8c9254cE18d93bD696108705803592A5cf5",
    // },
    // RToken: {
    // 	address: "0x5A6E5e6e9B3348db30416f3324BE16C4990B3eC2",
    // },
    // DebtToken: {
    // 	address: "0x3c1DFA96a42e01f6EaD0e7b340CC7581F5E1dD27",
    // },
    // RAACLendingPool: {
    // 	address: "0x107ddA227a9a35644385F5FF5B692Ba4D33079ae",
    // },
    // DEToken: {
    // 	address: "0x71E52ebabfb92372a34A712F9e61daa2Fc9036bB",
    // },
    // StabilityPool: {
    // 	address: "0xf3cF181c40f4Efd51b4134D8524119c9c554889B",
    // },
    // Treasury: {
    // 	address: "0xb9fc125256017ad46879474f351aDEf1144a2026",
    // },
    // RepairFund: {
    // 	address: "0xDaD56e9cA397103bCEC7CA2d681020ffF8293a1A",
    // },
    // FeeCollector: {
    // 	address: "0x45698266bcD25D605b8b9913DF22C6697029E57f",
    // },
    // RAACMinter: {
    // 	address: "0xAC54b4410a4335fc626F9cC9B801bC28B78A3AB6",
    // },
    // RAACHousePriceOracle: {
    // 	address: "0xdd90f99f75481EEe156c880C5f013163aC658394",
    // },
    // RAACPrimeRateOracle: {
    // 	address: "0x82ff7FC3d5b6091E2F1c6fca426F6d2b8F1c0B04",
    // },
}