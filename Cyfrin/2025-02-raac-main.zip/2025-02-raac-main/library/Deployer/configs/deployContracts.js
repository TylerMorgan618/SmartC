export default {
    contracts: {}
}