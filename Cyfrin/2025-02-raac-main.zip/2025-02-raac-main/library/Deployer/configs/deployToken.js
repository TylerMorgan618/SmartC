export default {
    tokenConfig: {},
}