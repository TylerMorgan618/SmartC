export default {
    contracts: [
        "RAACToken",
        "RAACReleaseOrchestrator",
        "RAACMinter",
        "RAACNFT",
        "RAACHousePrices",
        "StabilityPool",
    ]
}