export default {
    contracts: {},
}