# CLIMatic

This is encapsulated here as a module. Usually, we would use external libs or at least package this one.
However, for a security reason, we want a usage of a CLI with no externalities / packages, dependencies to reduce attack vectors.
This is made as a package just for sanity reason / maintenancy.  
