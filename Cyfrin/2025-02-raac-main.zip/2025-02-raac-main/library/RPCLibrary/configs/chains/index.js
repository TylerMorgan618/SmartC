import chain8453 from './8453.json' assert { type: 'json' };

const chains = {
    8453: chain8453,
}

export default chains;