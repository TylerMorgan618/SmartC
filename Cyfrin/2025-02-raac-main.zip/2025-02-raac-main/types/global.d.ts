declare module '/app.raac.io/src/providers/RPCProvider/methods/*' {
  const method: any;
  export default method;
}